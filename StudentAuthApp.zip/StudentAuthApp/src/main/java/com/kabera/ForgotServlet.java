package com.kabera;

import jakarta.servlet.http.HttpServlet;

public class ForgotServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

}
