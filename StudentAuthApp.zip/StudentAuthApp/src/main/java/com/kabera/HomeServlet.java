package com.kabera;

import jakarta.servlet.http.HttpServlet;

public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

}
